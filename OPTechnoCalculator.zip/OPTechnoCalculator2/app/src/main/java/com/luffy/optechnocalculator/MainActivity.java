package com.luffy.optechnocalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUnits, editTextRebate;
    private TextView textViewResult;
    private Button buttonCalculate, buttonAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUnits = findViewById(R.id.editTextUnits);
        editTextRebate = findViewById(R.id.editTextRebate);
        textViewResult = findViewById(R.id.textViewResult);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonAbout = findViewById(R.id.buttonAbout);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBill();
            }
        });

        buttonAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });
    }

    private void calculateBill() {
        // Input validation
        if (editTextUnits.getText().toString().isEmpty() || editTextRebate.getText().toString().isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double units;
        double rebate;

        try {
            units = Double.parseDouble(editTextUnits.getText().toString());
            rebate = Double.parseDouble(editTextRebate.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid input", Toast.LENGTH_SHORT).show();
            return;
        }

        if (units < 0 || rebate < 0 || rebate > 5) {
            Toast.makeText(MainActivity.this, "Invalid input values", Toast.LENGTH_SHORT).show();
            return;
        }

        double totalCost = calculateElectricityCost(units);
        double finalCost = totalCost - (totalCost * (rebate / 100));
        textViewResult.setText(String.format("Total cost after rebate: RM %.2f", finalCost));
    }

    private double calculateElectricityCost(double units) {
        double cost = 0.0;
        if (units <= 200) {
            cost = units * 0.218;
        } else if (units <= 300) {
            cost = 200 * 0.218 + (units - 200) * 0.334;
        } else if (units <= 600) {
            cost = 200 * 0.218 + 100 * 0.334 + (units - 300) * 0.516;
        } else {
            cost = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (units - 600) * 0.546;
        }
        return cost;
    }
}
